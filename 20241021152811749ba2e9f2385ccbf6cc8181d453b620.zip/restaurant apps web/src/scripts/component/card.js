const cardComponent = (id, imageUrl, restaurantName, rate, location) => {
  return `
  <div class="card" aria-label="Card content" role="card" tabindex="0" data-id="${id}">
  <img
    src="${imageUrl}"
    alt="Restaurant ${restaurantName}"
    loading="lazy"
    className="card-image"
  />
  <div className="overlay" data-id="${id}">
    <div className="rate">
      <i
        className="fa-regular fa-star star"
        aria-label="Simbol bintang"
      ></i>
      <p>${rate}</p>
    </div>

    <button
      type="button"
      className="detail-button"
      title="Tombol untuk melihat detail restoran"
      data-id="${id}"
    >
      <i
        className="fa-solid fa-circle-info info-icon"
        aria-label="Ikon informasi detail"
        data-id="${id}"
      ></i>
    </button>

    <div className="card-content" data-id="${id}">
      <p>
        <i
          className="fa-solid fa-map-location-dot"
          aria-label="Simbol lokasi peta"
        ></i>
        ${location}
      </p>
      <h2>${restaurantName}</h2>
    </div>
  </div>
</div>
  `;
};

export default cardComponent;
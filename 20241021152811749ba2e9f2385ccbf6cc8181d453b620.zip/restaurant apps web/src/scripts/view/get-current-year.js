const updateYearText = () => {
  // Ambil semua elemen dengan kelas 'year'
  const yearElements = document.querySelectorAll('.year');
  
  // Dapatkan tahun saat ini
  const currentYear = new Date().getFullYear();

  // Perbarui teks konten untuk setiap elemen 'year'
  yearElements.forEach(element => {
    element.textContent = currentYear;
  });
};

// Eksekusi fungsi untuk memperbarui tahun pada halaman
updateYearText();

export default updateYearText;

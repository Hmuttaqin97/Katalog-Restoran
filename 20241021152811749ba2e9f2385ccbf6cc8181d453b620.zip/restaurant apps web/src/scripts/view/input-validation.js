// Ambil semua elemen input umum dan elemen spesifik dari DOM
const inputs = {
  name: document.querySelector("#name"),
  email: document.querySelector("#email"),
  company: document.querySelector("#company"),
  message: document.querySelector("#message")
};

// Ambil elemen notifikasi validasi untuk setiap input
const notifications = {
  name: document.querySelector(".notification-name"),
  email: document.querySelector(".notification-email"),
  company: document.querySelector(".notification-company"),
  message: document.querySelector(".notification-message")
};

// Regex untuk validasi email
const emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

// Tombol submit
const submitButton = document.querySelector(".button-submit");

// Fungsi validasi input
const validateInputs = () => {
  const { name, email, company, message } = inputs;
  
  // Validasi tiap input berdasarkan panjang dan pola regex
  const validations = {
    name: name.value.length >= 3,
    email: emailRegex.test(email.value),
    company: company.value.length >= 3,
    message: message.value.length >= 5
  };

  // Toggle notifikasi berdasarkan validasi input
  for (const key in validations) {
    const isValid = validations[key];
    const notification = notifications[key];

    if (isValid) {
      notification.classList.replace("show-notification", "hide-notification");
    } else {
      notification.classList.replace("hide-notification", "show-notification");
    }
  }

  // Aktifkan atau nonaktifkan tombol submit berdasarkan hasil validasi
  const allValid = Object.values(validations).every(Boolean);
  submitButton.disabled = !allValid;
  submitButton.classList.toggle("allowed", allValid);
  submitButton.classList.toggle("not-allowed", !allValid);
};

// Tambahkan event listener untuk setiap input
Object.values(inputs).forEach((input) => {
  input.addEventListener("input", validateInputs);
});

// Inisialisasi validasi awal
validateInputs();

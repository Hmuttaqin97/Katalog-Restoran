import modalBodyComponent from "../component/modal-body.js";
import dataRestaurants from "../../DATA.json";

const generateModalBody = (datasetID) => {
  // Ambil elemen modal-body untuk menampilkan konten
  const modalBody = document.querySelector(".modal-body");

  // Cari restoran yang sesuai dengan datasetID
  const restaurant = dataRestaurants.restaurants.find(({ id }) => id === datasetID);

  // Jika restoran ditemukan, tampilkan detail di dalam modal
  if (restaurant) {
    const { name, description, pictureId: image, city, rating } = restaurant;
    
    // Set innerHTML modal-body dengan komponen modalBodyComponent
    modalBody.innerHTML = modalBodyComponent(image, name, rating, city, description);
  } else {
    console.error("Restoran dengan ID tersebut tidak ditemukan.");
  }
};

export default generateModalBody;

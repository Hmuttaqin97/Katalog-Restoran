import cardComponent from "../component/card.js";
import dataRestaurants from "../../DATA.json";

const generateCard = () => {
  // Dapatkan elemen card-container dari DOM
  const cardContainer = document.querySelector(".card-container");

  // Hapus konten yang ada di dalam card-container sebelum menambahkan kartu baru
  cardContainer.innerHTML = "";

  // Destrukturisasi data restoran dari JSON
  const { restaurants } = dataRestaurants;

  // Map setiap restoran menjadi komponen kartu dan gabungkan ke dalam card-container
  const cards = restaurants.map(({ id, name, pictureId: image, city, rating }) =>
    cardComponent(id, image, name, rating, city)
  );

  // Gabungkan seluruh kartu dan tambahkan ke dalam card-container
  cardContainer.innerHTML = cards.join("");
};

export default generateCard;

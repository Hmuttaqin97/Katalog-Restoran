import generateModalBody from "./generate-modal-body";

const DURATION_TIMEOUT = 400;
const cardContainer = document.querySelector(".card-container");
const modalParent = document.querySelector(".modal-parent");
const modalButtonClose = modalParent.querySelector(".modal-button-close");
const body = document.body;

// Fungsi untuk menampilkan modal
const showModal = () => {
  modalParent.classList.add("block");
  setTimeout(() => {
    modalParent.classList.add("show-modal");
    body.classList.add("modal-freeze-page");
  }, DURATION_TIMEOUT);
};

// Fungsi untuk menyembunyikan modal
const hideModal = () => {
  modalParent.classList.remove("show-modal");
  body.classList.remove("modal-freeze-page");
  setTimeout(() => {
    modalParent.classList.remove("block");
  }, DURATION_TIMEOUT);
};

// Fungsi untuk memeriksa apakah tombol detail di-klik
const isDetailButtonClicked = (target) =>
  target.classList.contains("detail-button") || target.classList.contains("info-icon");

// Fungsi untuk memeriksa apakah elemen kartu di-klik
const isCardClicked = (target) =>
  target.classList.contains("overlay") || target.classList.contains("card-content") || target.classList.contains("rate");

// Event handler untuk menampilkan modal saat elemen kartu atau tombol detail di-klik
const handleCardClick = (event) => {
  const target = event.target;
  const cardId = target.dataset.id;

  if (isDetailButtonClicked(target) || isCardClicked(target)) {
    generateModalBody(cardId);
    showModal();
  }
};

// Event listener untuk menutup modal saat tombol close di-klik
modalButtonClose.addEventListener("click", hideModal);

// Menerapkan event delegation untuk elemen container kartu
cardContainer.addEventListener("click", handleCardClick);

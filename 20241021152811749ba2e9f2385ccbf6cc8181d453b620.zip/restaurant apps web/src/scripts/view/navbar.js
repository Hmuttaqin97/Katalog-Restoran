// Durasi transisi untuk perubahan ikon dan navigasi
const TRANSITION_DURATION = 500;

// Elemen tombol hamburger dan daftar navigasi mobile
const hamburgerButton = document.querySelector(".hum-button");
const mobileNavList = document.querySelector(".nav-list.mobile");
const buttonIcon = document.querySelector(".button-icon");

// Fungsi untuk mengubah ikon tombol hamburger
const toggleIcon = (isBurger) => {
  buttonIcon.classList.replace("fade", "not-fade");
  setTimeout(() => {
    buttonIcon.classList.replace("not-fade", "fade");
    buttonIcon.classList.replace(isBurger ? "fa-burger" : "fa-xmark", isBurger ? "fa-xmark" : "fa-burger");
  }, TRANSITION_DURATION);
};

// Fungsi untuk menampilkan atau menyembunyikan navigasi mobile
const toggleMobileNav = (isBurger) => {
  if (isBurger) {
    mobileNavList.classList.replace("hide", "show");
    setTimeout(() => {
      mobileNavList.classList.add("open");
    }, TRANSITION_DURATION);
  } else {
    mobileNavList.classList.remove("open");
    setTimeout(() => {
      mobileNavList.classList.replace("show", "hide");
    }, TRANSITION_DURATION);
  }
};

// Event listener untuk tombol hamburger
hamburgerButton.addEventListener("click", () => {
  const isBurgerIcon = buttonIcon.classList.contains("fa-burger");
  toggleIcon(isBurgerIcon);
  toggleMobileNav(isBurgerIcon);
});

// Menambahkan kelas 'active' pada navbar saat scroll melewati header
const headerElement = document.querySelector("header");
const navbarElement = document.querySelector(".navbar");

window.addEventListener("scroll", () => {
  const hasScrolled = window.scrollY > headerElement.offsetHeight - 10;
  navbarElement.classList.toggle("active", hasScrolled);
});
